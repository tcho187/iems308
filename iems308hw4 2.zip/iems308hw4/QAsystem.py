
# coding: utf-8

# In[1]:

#Thomas Cho
#IEMS 308

import pandas as pd
import os
import re
import numpy as np
from sklearn.feature_extraction.text import CountVectorizer, TfidfTransformer
import io
from sklearn.naive_bayes import MultinomialNB
from sklearn.metrics import classification_report, f1_score, accuracy_score, confusion_matrix
from sklearn.cross_validation import train_test_split 
import nltk.data
from nltk.stem.porter import PorterStemmer


# In[2]:

#Initialize panda DataFrame
df = pd.DataFrame()


# In[3]:

# #Read each text file
# #split text into sentences using regular expression. Logic--> sentence ends in !.? and . is not between numbers or letters
# #append each sentence as row
# #http://stackoverflow.com/questions/4576077/python-split-text-on-sentences --> source for sentence segmentation
# tokenizer = nltk.data.load('tokenizers/punkt/english.pickle')
# for s in ('2013','2014'):
#     path = '/Users/Tcho187/Documents/Senior_year/iems308text/%s' % (s)
#     for file in os.listdir(path):
#         if file == '.DS_Store':
#             continue
#         with io.open(os.path.join(path,file),'r',encoding='utf-8',errors='ignore') as infile:
#             txt = infile.read().lower()
#         sentences = re.split(r'!|\?|\.{3}|\.\D|\.\s', txt)
#         df = df.append(tokenizer.tokenize(txt),ignore_index=True)


# In[4]:

#Read each text file
#split text into sentences using regular expression. Logic--> sentence ends in !.? and . is not between numbers or letters
#append each sentence as row
#http://stackoverflow.com/questions/4576077/python-split-text-on-sentences --> source for sentence segmentation
tokenizer = nltk.data.load('tokenizers/punkt/english.pickle')
for s in ('2013','2014'):
    path = '/Users/Tcho187/Documents/Senior_year/iems308text/%s' % (s)
    for file in os.listdir(path):
        if file == '.DS_Store':
            continue
        with io.open(os.path.join(path,file),'r',encoding='utf-8',errors='ignore') as infile:
            txt = infile.read()
        paragraphs = re.split(r'\n', txt)
#         df = df.append(tokenizer.tokenize(txt),ignore_index=True)
        df = df.append(paragraphs,ignore_index=True)


# In[5]:

query_df = pd.DataFrame()
tokenizer = nltk.data.load('tokenizers/punkt/english.pickle')
query_path = '/Users/Tcho187/Documents/Senior_year/iems308text/query'
for file in os.listdir(query_path):
    if file == '.DS_Store':
        continue
    with io.open(os.path.join(query_path,file),'r',encoding='utf-8',errors='ignore')as infile:
        query = infile.read().lower()
    query_df = query_df.append(tokenizer.tokenize(query),ignore_index=True)


# In[6]:

#Give text a header
df.columns=['text']
query_df.columns=['text']


# In[7]:

# query_df2=query_df.drop(query_df.index[[0]])
# print query_df


# In[8]:

frames = [query_df, df]
total_df = pd.concat(frames)


# In[9]:

total_df=total_df.reset_index()


# In[10]:

print total_df


# In[11]:

from sklearn.feature_extraction.text import CountVectorizer
vectorizer = CountVectorizer(stop_words='english')


# In[12]:

feature_list = total_df['text'].tolist()
feature_list=vectorizer.fit_transform(feature_list)


# In[13]:

# query_list = query_df['query'].tolist()
# query_matrix = vectorizer.transform(query_list)


# In[14]:

# print query_matrix


# In[15]:

# query_matrix.todense()


# In[16]:

tfidf = TfidfTransformer().fit_transform(feature_list)


# In[17]:

tfidf


# In[18]:

print tfidf[0:1,]


# In[19]:

from sklearn.metrics.pairwise import cosine_similarity
cos=cosine_similarity(tfidf[0:1], tfidf)


# In[20]:

related_docs_indices = cos.argsort()[:-3:-1]


# In[21]:

related_docs_indices


# In[22]:

related_docs_indices[0,-1]


# In[23]:

pd.options.display.max_colwidth = 100000


# In[24]:

print total_df.loc[0,['text']]


# In[ ]:




# In[25]:

for i in range(-2,-5,-1):
#     print total_df.loc[(related_docs_indices[0,i]),['text']] 
    print "%s \n" % (total_df.loc[(related_docs_indices[0,i]),['text']])


# In[ ]:



